def detecterrornums(nums):
    numSet = set()
    duplicate = 0
    missing = 0
    for num in nums:
        if num in numSet:
            duplicate = num
        numSet.add(num)
    expectedSum = len(nums) * (len(nums) + 1) // 2
    actualSum = sum(nums)
    missing = expectedSum - actualSum + duplicate
    return [duplicate, missing]
nums = [1, 2, 2, 4]
result = detecterrornums(nums)
print("Output:", result)
